#include "crypto_verify_32.h"

size_t
crypto_verify_32_bytes(void) {
    return crypto_verify_32_BYTES;
}
